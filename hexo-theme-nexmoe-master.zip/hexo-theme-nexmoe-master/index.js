// 这个文件用来防止 hexo 5.0.0 使用 "hexo clean" 命令报错。
// This file is used to prevent hexo 5.0.0 from using "hexo clean" command error.
