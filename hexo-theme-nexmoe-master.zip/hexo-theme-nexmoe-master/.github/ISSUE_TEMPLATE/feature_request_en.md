---
name: 🍰 Feature Request
about: Submit a new feature request
---

<!--
Feature Request(https://docs.nexmoe.com) or [issue](https://github.com/nexmoe/hexo-theme-nexmoe/issues) , and provide all the information required by this template.
Otherwise the issue will be closed immediately.
-->

### What feature is it?

### What can this function do?

### Additional description